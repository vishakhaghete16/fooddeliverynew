package com.fooddelivery.auth.service;

import lombok.RequiredArgsConstructor;
import lombok.extern.slf4j.Slf4j;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.mail.SimpleMailMessage;
import org.springframework.mail.javamail.JavaMailSender;
import org.springframework.stereotype.Service;

@Service
@RequiredArgsConstructor
@Slf4j
public class EmailService {
    
    private final JavaMailSender mailSender;
    
    @Value("${spring.mail.username}")
    private String fromEmail;
    
    public void sendWelcomeEmail(String toEmail, String userName) {
        try {
            log.info("Sending welcome email to: {}", toEmail);
            
            SimpleMailMessage message = new SimpleMailMessage();
            message.setFrom(fromEmail);
            message.setTo(toEmail);
            message.setSubject("Registration Successful");
            message.setText(String.format(
                "Hello %s,\n\n" +
                "Welcome to Food Delivery App. You are successfully registered.\n\n" +
                "Thank you for joining us!\n\n" +
                "Best regards,\n" +
                "Food Delivery Team",
                userName
            ));
            
            mailSender.send(message);
            
            log.info("Successfully sent welcome email to: {}", toEmail);
        } catch (Exception e) {
            log.error("Error sending welcome email to: {}", toEmail, e);
            // Don't throw exception - email failure shouldn't break registration
        }
    }
}
