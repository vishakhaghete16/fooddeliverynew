package com.fooddelivery.auth.service;

import com.fooddelivery.auth.event.UserRegistrationEvent;
import lombok.RequiredArgsConstructor;
import lombok.extern.slf4j.Slf4j;
import org.springframework.kafka.annotation.KafkaListener;
import org.springframework.stereotype.Service;

@Service
@RequiredArgsConstructor
@Slf4j
public class KafkaConsumerService {
    
    private final EmailService emailService;
    
    @KafkaListener(
            topics = "${kafka.topic.user-registration}",
            groupId = "${spring.kafka.consumer.group-id}"
    )
    public void consumeUserRegistrationEvent(UserRegistrationEvent event) {
        try {
            log.info("Consumed user registration event for email: {}", event.getEmail());
            
            // Send welcome email
            emailService.sendWelcomeEmail(event.getEmail(), event.getUserName());
            
            log.info("Processed user registration event for: {}", event.getEmail());
        } catch (Exception e) {
            log.error("Error processing user registration event for: {}", event.getEmail(), e);
        }
    }
}
