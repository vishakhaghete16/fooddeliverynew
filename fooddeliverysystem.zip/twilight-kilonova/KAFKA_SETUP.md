# Kafka Setup Guide

This guide will help you set up Apache Kafka to enable the event-driven architecture for user registration notifications.

## Option 1: Docker Setup (Recommended - Easiest)

### Prerequisites
- Docker Desktop installed on Windows

### Steps

1. **Create docker-compose.yml** (already created in the project root)

2. **Start Kafka using Docker Compose**
```powershell
cd c:\Users\visha\.gemini\antigravity\playground\twilight-kilonova
docker-compose up -d
```

3. **Verify Kafka is running**
```powershell
docker ps
```

You should see two containers running:
- `zookeeper`
- `kafka`

4. **Stop Kafka** (when needed)
```powershell
docker-compose down
```

---

## Option 2: Local Installation (Windows)

### Prerequisites
- Java 17+ installed

### Steps

1. **Download Kafka**
   - Visit: https://kafka.apache.org/downloads
   - Download the latest binary (e.g., `kafka_2.13-3.6.0.tgz`)

2. **Extract Kafka**
   - Extract to `C:\kafka`

3. **Start Zookeeper**
```powershell
cd C:\kafka
.\bin\windows\zookeeper-server-start.bat .\config\zookeeper.properties
```

4. **Start Kafka Server** (in a new terminal)
```powershell
cd C:\kafka
.\bin\windows\kafka-server-start.bat .\config\server.properties
```

5. **Verify Kafka is running**
```powershell
.\bin\windows\kafka-topics.bat --list --bootstrap-server localhost:9092
```

---

## Email Configuration

### Using Gmail SMTP

1. **Enable 2-Step Verification** on your Gmail account
   - Go to: https://myaccount.google.com/security
   - Enable 2-Step Verification

2. **Generate App Password**
   - Go to: https://myaccount.google.com/apppasswords
   - Select "Mail" and your device
   - Copy the generated 16-character password

3. **Update application.properties**
```properties
spring.mail.username=your-email@gmail.com
spring.mail.password=your-16-char-app-password
```

### Using Other Email Services

**SendGrid:**
```properties
spring.mail.host=smtp.sendgrid.net
spring.mail.port=587
spring.mail.username=apikey
spring.mail.password=your-sendgrid-api-key
```

**Outlook/Hotmail:**
```properties
spring.mail.host=smtp-mail.outlook.com
spring.mail.port=587
spring.mail.username=your-email@outlook.com
spring.mail.password=your-password
```

---

## Testing the Integration

### 1. Start Kafka
```powershell
# If using Docker
docker-compose up -d

# If using local installation
# Start Zookeeper and Kafka as shown above
```

### 2. Start the Spring Boot Application
```powershell
cd backend
mvn spring-boot:run
```

### 3. Register a New User

**Using Frontend:**
- Navigate to http://localhost:5173
- Fill out the signup form
- Submit

**Using Postman/curl:**
```bash
curl -X POST http://localhost:8080/api/auth/signup \
  -H "Content-Type: application/json" \
  -d '{
    "fullName": "Test User",
    "email": "test@example.com",
    "phone": "1234567890",
    "password": "password123",
    "confirmPassword": "password123"
  }'
```

### 4. Check Logs

You should see logs indicating:
1. **Producer**: "Publishing user registration event for email: test@example.com"
2. **Consumer**: "Consumed user registration event for email: test@example.com"
3. **Email**: "Sending welcome email to: test@example.com"

### 5. Verify Email

Check the email inbox for the welcome message:
- **Subject**: Registration Successful
- **Body**: Welcome message

---

## Monitoring Kafka

### View Kafka Topics
```powershell
# Docker
docker exec -it kafka kafka-topics --list --bootstrap-server localhost:9092

# Local
.\bin\windows\kafka-topics.bat --list --bootstrap-server localhost:9092
```

### View Messages in Topic
```powershell
# Docker
docker exec -it kafka kafka-console-consumer --bootstrap-server localhost:9092 --topic user-registration-topic --from-beginning

# Local
.\bin\windows\kafka-console-consumer.bat --bootstrap-server localhost:9092 --topic user-registration-topic --from-beginning
```

---

## Troubleshooting

### Kafka Connection Issues

**Error**: "Connection to node -1 could not be established"

**Solution**:
- Ensure Kafka is running: `docker ps` or check local processes
- Verify port 9092 is not blocked by firewall
- Check `spring.kafka.bootstrap-servers=localhost:9092` in application.properties

### Email Not Sending

**Error**: "Authentication failed"

**Solution**:
- Verify email credentials in application.properties
- For Gmail, ensure you're using an App Password, not your regular password
- Check if 2-Step Verification is enabled
- Verify SMTP settings are correct

**Error**: "Could not connect to SMTP host"

**Solution**:
- Check internet connection
- Verify SMTP host and port
- Check firewall settings

### Consumer Not Receiving Messages

**Solution**:
- Check consumer group ID is correct
- Verify topic name matches: `user-registration-topic`
- Check application logs for consumer errors
- Ensure Kafka is running

---

## Architecture Flow

```
User Registration
      ↓
AuthService.signup()
      ↓
Save User to Database
      ↓
Create UserRegistrationEvent
      ↓
KafkaProducerService → Publish to Kafka Topic
      ↓
Kafka Topic: user-registration-topic
      ↓
KafkaConsumerService ← Consume from Kafka Topic
      ↓
EmailService.sendWelcomeEmail()
      ↓
User receives welcome email
```

---

## Configuration Reference

### Kafka Properties
```properties
# Kafka Bootstrap Server
spring.kafka.bootstrap-servers=localhost:9092

# Consumer Configuration
spring.kafka.consumer.group-id=auth-service-group
spring.kafka.consumer.auto-offset-reset=earliest

# Topic Name
kafka.topic.user-registration=user-registration-topic
```

### Email Properties
```properties
# Gmail SMTP
spring.mail.host=smtp.gmail.com
spring.mail.port=587
spring.mail.username=your-email@gmail.com
spring.mail.password=your-app-password
spring.mail.properties.mail.smtp.auth=true
spring.mail.properties.mail.smtp.starttls.enable=true
```

---

## Next Steps

1. ✅ Install Kafka (Docker or local)
2. ✅ Configure email credentials
3. ✅ Start Kafka
4. ✅ Start Spring Boot application
5. ✅ Test user registration
6. ✅ Verify email delivery

For production deployment, consider:
- Using managed Kafka services (Confluent Cloud, AWS MSK)
- Implementing retry logic for failed emails
- Adding dead letter queues for failed events
- Monitoring Kafka lag and consumer health
