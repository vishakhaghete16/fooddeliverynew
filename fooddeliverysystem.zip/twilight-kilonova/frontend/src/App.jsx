import { useState } from 'react';
import Auth from './components/Auth';
import Toast from './components/Toast';
import './App.css';

function App() {
    const [toast, setToast] = useState(null);

    const showToast = (message, type) => {
        setToast({ message, type });
    };

    const closeToast = () => {
        setToast(null);
    };

    return (
        <div className="app">
            <Auth onToast={showToast} />
            {toast && (
                <Toast
                    message={toast.message}
                    type={toast.type}
                    onClose={closeToast}
                />
            )}
        </div>
    );
}

export default App;
