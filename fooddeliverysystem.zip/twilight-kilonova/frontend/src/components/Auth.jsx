import React, { useState } from 'react';
import SignUp from './SignUp';
import Login from './Login';
import './Auth.css';

const Auth = ({ onToast }) => {
    const [activeTab, setActiveTab] = useState('login');

    return (
        <div className="auth-container">
            <div className="auth-card">
                <div className="auth-header">
                    <h1>Authentication</h1>
                    <p className="tagline">Sign in to your account</p>
                </div>

                <div className="tab-container">
                    <button
                        className={`tab ${activeTab === 'login' ? 'active' : ''}`}
                        onClick={() => setActiveTab('login')}
                    >
                        Log In
                    </button>
                    <button
                        className={`tab ${activeTab === 'signup' ? 'active' : ''}`}
                        onClick={() => setActiveTab('signup')}
                    >
                        Sign Up
                    </button>
                    <div className={`tab-indicator ${activeTab === 'signup' ? 'right' : ''}`} />
                </div>

                <div className="form-container">
                    {activeTab === 'signup' ? (
                        <SignUp
                            onSuccess={onToast}
                            onSwitchToLogin={() => setActiveTab('login')}
                        />
                    ) : (
                        <Login
                            onSuccess={onToast}
                            onSwitchToSignup={() => setActiveTab('signup')}
                        />
                    )}
                </div>
            </div>
        </div>
    );
};

export default Auth;
