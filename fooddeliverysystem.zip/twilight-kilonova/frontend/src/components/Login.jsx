import React, { useState } from 'react';
import authService from '../services/authService';
import './SignUp.css';

const Login = ({ onSuccess, onSwitchToSignup }) => {
    const [formData, setFormData] = useState({
        emailOrPhone: '',
        password: ''
    });
    const [errors, setErrors] = useState({});
    const [loading, setLoading] = useState(false);

    const handleChange = (e) => {
        const { name, value } = e.target;
        setFormData(prev => ({
            ...prev,
            [name]: value
        }));
        // Clear error when user starts typing
        if (errors[name]) {
            setErrors(prev => ({
                ...prev,
                [name]: ''
            }));
        }
    };

    const validateForm = () => {
        const newErrors = {};

        if (!formData.emailOrPhone.trim()) {
            newErrors.emailOrPhone = 'Email or phone number is required';
        }

        if (!formData.password) {
            newErrors.password = 'Password is required';
        }

        setErrors(newErrors);
        return Object.keys(newErrors).length === 0;
    };

    const handleSubmit = async (e) => {
        e.preventDefault();

        if (!validateForm()) {
            return;
        }

        setLoading(true);
        try {
            const response = await authService.login(formData);
            onSuccess(`Welcome back, ${response.fullName}!`, 'success');
        } catch (error) {
            const errorMessage = error.message || 'Login failed. Please check your credentials.';
            onSuccess(errorMessage, 'error');
        } finally {
            setLoading(false);
        }
    };

    return (
        <form className="login-form" onSubmit={handleSubmit}>
            <div className="form-group">
                <label htmlFor="emailOrPhone">Email or Phone Number</label>
                <input
                    type="text"
                    id="emailOrPhone"
                    name="emailOrPhone"
                    value={formData.emailOrPhone}
                    onChange={handleChange}
                    placeholder="Enter email or phone number"
                    disabled={loading}
                />
                {errors.emailOrPhone && <span className="error-text">{errors.emailOrPhone}</span>}
            </div>

            <div className="form-group">
                <label htmlFor="password">Password</label>
                <input
                    type="password"
                    id="password"
                    name="password"
                    value={formData.password}
                    onChange={handleChange}
                    placeholder="Enter your password"
                    disabled={loading}
                />
                {errors.password && <span className="error-text">{errors.password}</span>}
            </div>

            <button type="submit" className="submit-btn" disabled={loading}>
                {loading ? (
                    <span className="loading-spinner">Logging In...</span>
                ) : (
                    'Log In'
                )}
            </button>

            <p className="switch-text">
                Don't have an account?{' '}
                <button type="button" className="link-btn" onClick={onSwitchToSignup}>
                    Sign Up
                </button>
            </p>
        </form>
    );
};

export default Login;
