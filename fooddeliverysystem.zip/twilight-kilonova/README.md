# Food Delivery Authentication Service 🍕

A complete **User Registration and Authentication Service** built with **Spring Boot** (backend) and **React** (frontend), featuring JWT-based authentication and a modern, clean UI.

![Tech Stack](https://img.shields.io/badge/Spring%20Boot-3.2.0-brightgreen)
![React](https://img.shields.io/badge/React-18.2.0-blue)
![MySQL](https://img.shields.io/badge/MySQL-8.0-orange)
![JWT](https://img.shields.io/badge/JWT-Authentication-red)

## 📋 Table of Contents

- [Features](#features)
- [Technology Stack](#technology-stack)
- [Project Structure](#project-structure)
- [Prerequisites](#prerequisites)
- [Database Setup](#database-setup)
- [Backend Setup](#backend-setup)
- [Frontend Setup](#frontend-setup)
- [API Documentation](#api-documentation)
- [Environment Configuration](#environment-configuration)

## ✨ Features

### Authentication
- ✅ User registration with validation
- ✅ Login with email or phone number
- ✅ JWT token-based authentication
- ✅ Password encryption using BCrypt
- ✅ Secure token storage

### UI/UX
- 🎨 Modern, clean, and responsive design
- 🌙 Dark theme with vibrant accents
- 📱 Mobile-friendly interface
- ✨ Smooth animations and transitions
- 🔔 Toast notifications for user feedback
- ⚡ Loading states and error handling

### Security
- 🔒 Password hashing with BCrypt
- 🔑 JWT token authentication
- 🛡️ Input validation on frontend and backend
- 🚫 Protected API endpoints
- ⚠️ Proper error messages without sensitive data leakage

## 🛠️ Technology Stack

### Backend
- **Framework:** Spring Boot 3.2.0
- **Language:** Java 17
- **Security:** Spring Security + JWT
- **Database:** MySQL 8.0
- **ORM:** Spring Data JPA / Hibernate
- **Build Tool:** Maven

### Frontend
- **Framework:** React 18.2.0
- **Build Tool:** Vite 5.0
- **HTTP Client:** Axios
- **Styling:** Vanilla CSS with CSS Variables
- **Fonts:** Google Fonts (Inter)

## 📁 Project Structure

```
twilight-kilonova/
├── backend/                          # Spring Boot Application
│   ├── src/main/java/com/fooddelivery/auth/
│   │   ├── AuthServiceApplication.java
│   │   ├── config/
│   │   │   └── SecurityConfig.java
│   │   ├── controller/
│   │   │   └── AuthController.java
│   │   ├── dto/
│   │   │   ├── SignupRequest.java
│   │   │   ├── LoginRequest.java
│   │   │   └── AuthResponse.java
│   │   ├── entity/
│   │   │   └── User.java
│   │   ├── exception/
│   │   │   ├── CustomException.java
│   │   │   └── GlobalExceptionHandler.java
│   │   ├── repository/
│   │   │   └── UserRepository.java
│   │   ├── security/
│   │   │   └── JwtAuthenticationFilter.java
│   │   └── service/
│   │       ├── AuthService.java
│   │       └── JwtService.java
│   ├── src/main/resources/
│   │   └── application.properties
│   └── pom.xml
│
├── frontend/                         # React Application
│   ├── src/
│   │   ├── components/
│   │   │   ├── Auth.jsx
│   │   │   ├── Auth.css
│   │   │   ├── Login.jsx
│   │   │   ├── SignUp.jsx
│   │   │   ├── SignUp.css
│   │   │   ├── Toast.jsx
│   │   │   └── Toast.css
│   │   ├── services/
│   │   │   └── authService.js
│   │   ├── App.jsx
│   │   ├── App.css
│   │   ├── index.css
│   │   └── main.jsx
│   ├── index.html
│   ├── package.json
│   └── vite.config.js
│
├── database/
│   └── schema.sql                    # MySQL Schema
│
└── README.md
```

## 📦 Prerequisites

Before you begin, ensure you have the following installed:

- **Java 17** or higher ([Download](https://www.oracle.com/java/technologies/downloads/))
- **Maven 3.6+** ([Download](https://maven.apache.org/download.cgi))
- **Node.js 18+** and **npm** ([Download](https://nodejs.org/))
- **MySQL 8.0+** ([Download](https://dev.mysql.com/downloads/mysql/))

Verify installations:
```bash
java -version
mvn -version
node -version
npm -version
mysql --version
```

## 🗄️ Database Setup

### 1. Start MySQL Server

Make sure your MySQL server is running.

### 2. Create Database and Table

**Option 1: Using MySQL Command Line**
```bash
mysql -u root -p
```

Then run:
```sql
CREATE DATABASE IF NOT EXISTS food_delivery_auth;
USE food_delivery_auth;

CREATE TABLE IF NOT EXISTS users (
    id BIGINT AUTO_INCREMENT PRIMARY KEY,
    full_name VARCHAR(100) NOT NULL,
    email VARCHAR(255) NOT NULL UNIQUE,
    phone VARCHAR(10) NOT NULL UNIQUE,
    password VARCHAR(255) NOT NULL,
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    updated_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
    INDEX idx_email (email),
    INDEX idx_phone (phone)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
```

**Option 2: Using SQL File**
```bash
mysql -u root -p < database/schema.sql
```

### 3. Configure Database Credentials

If your MySQL credentials are different from the defaults, update `backend/src/main/resources/application.properties`:

```properties
spring.datasource.username=YOUR_USERNAME
spring.datasource.password=YOUR_PASSWORD
```

## 🚀 Backend Setup

### 1. Navigate to Backend Directory
```bash
cd backend
```

### 2. Install Dependencies
```bash
mvn clean install
```

### 3. Run the Application
```bash
mvn spring-boot:run
```

The backend server will start on **http://localhost:8080**

### 4. Verify Backend is Running
Open your browser or use curl:
```bash
curl http://localhost:8080/api/auth/health
```

Expected response: `Auth Service is running!`

## 💻 Frontend Setup

### 1. Navigate to Frontend Directory
```bash
cd frontend
```

### 2. Install Dependencies
```bash
npm install
```

### 3. Run the Development Server
```bash
npm run dev
```

The frontend will start on **http://localhost:5173**

### 4. Open in Browser
Navigate to [http://localhost:5173](http://localhost:5173)

## 📡 API Documentation

### Base URL
```
http://localhost:8080/api/auth
```

### Endpoints

#### 1. Sign Up
**POST** `/api/auth/signup`

**Request Body:**
```json
{
  "fullName": "John Doe",
  "email": "john.doe@example.com",
  "phone": "9876543210",
  "password": "password123",
  "confirmPassword": "password123"
}
```

**Success Response (201 Created):**
```json
{
  "token": "eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCJ9...",
  "type": "Bearer",
  "id": 1,
  "fullName": "John Doe",
  "email": "john.doe@example.com",
  "phone": "9876543210"
}
```

**Error Response (400 Bad Request):**
```json
{
  "timestamp": "2026-02-10T10:55:23",
  "message": "Email already registered",
  "status": 400
}
```

#### 2. Log In
**POST** `/api/auth/login`

**Request Body:**
```json
{
  "emailOrPhone": "john.doe@example.com",
  "password": "password123"
}
```

**Success Response (200 OK):**
```json
{
  "token": "eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCJ9...",
  "type": "Bearer",
  "id": 1,
  "fullName": "John Doe",
  "email": "john.doe@example.com",
  "phone": "9876543210"
}
```

**Error Response (400 Bad Request):**
```json
{
  "timestamp": "2026-02-10T10:55:23",
  "message": "Invalid credentials",
  "status": 400
}
```

#### 3. Health Check
**GET** `/api/auth/health`

**Success Response (200 OK):**
```
Auth Service is running!
```

### Validation Rules

#### Sign Up
- **Full Name:** Required, 2-100 characters
- **Email:** Required, valid email format
- **Phone:** Required, exactly 10 digits
- **Password:** Required, minimum 6 characters
- **Confirm Password:** Must match password

#### Log In
- **Email or Phone:** Required
- **Password:** Required

## ⚙️ Environment Configuration

### Backend Configuration
File: `backend/src/main/resources/application.properties`

```properties
# Server Configuration
server.port=8080

# Database Configuration
spring.datasource.url=jdbc:mysql://localhost:3306/food_delivery_auth
spring.datasource.username=root
spring.datasource.password=root

# JWT Configuration
jwt.secret=YOUR_SECRET_KEY_HERE
jwt.expiration=86400000  # 24 hours in milliseconds

# JPA Configuration
spring.jpa.hibernate.ddl-auto=update
spring.jpa.show-sql=true
```

### Frontend Configuration
File: `frontend/src/services/authService.js`

```javascript
const API_BASE_URL = 'http://localhost:8080/api/auth';
```

## 🧪 Testing the Application

### 1. Test Sign Up Flow
1. Open http://localhost:5173
2. Click on "Sign Up" tab
3. Fill in the registration form
4. Click "Sign Up" button
5. Verify success toast message
6. Check MySQL database for new user record

### 2. Test Log In Flow
1. Click on "Log In" tab
2. Enter registered email/phone and password
3. Click "Log In" button
4. Verify success toast with welcome message
5. Check browser localStorage for JWT token

### 3. Test Validation
- Try submitting empty forms
- Enter invalid email format
- Enter phone number with less/more than 10 digits
- Enter password less than 6 characters
- Enter mismatched passwords in Sign Up
- Try registering with existing email/phone

## 🎨 UI Features

- **Responsive Design:** Works seamlessly on desktop, tablet, and mobile
- **Tab Navigation:** Smooth animated tab switching between Login and Sign Up
- **Form Validation:** Real-time validation with error messages
- **Loading States:** Visual feedback during API calls
- **Toast Notifications:** Success and error messages with auto-dismiss
- **Modern Aesthetics:** Dark theme with vibrant gradients and smooth animations

## 🔐 Security Features

- **Password Encryption:** BCrypt hashing algorithm
- **JWT Tokens:** Secure token-based authentication
- **CORS Enabled:** Configured for cross-origin requests
- **Input Validation:** Both frontend and backend validation
- **SQL Injection Protection:** JPA/Hibernate parameterized queries
- **Unique Constraints:** Email and phone uniqueness enforced at database level

## 🐛 Troubleshooting

### Backend Issues

**Problem:** `Cannot connect to database`
- Verify MySQL is running
- Check database credentials in `application.properties`
- Ensure database `food_delivery_auth` exists

**Problem:** `Port 8080 already in use`
- Change port in `application.properties`: `server.port=8081`
- Update frontend API URL accordingly

### Frontend Issues

**Problem:** `npm install` fails
- Delete `node_modules` and `package-lock.json`
- Run `npm install` again

**Problem:** API calls fail with CORS error
- Verify backend is running on port 8080
- Check `@CrossOrigin` annotation in `AuthController.java`

**Problem:** `Port 5173 already in use`
- Change port in `vite.config.js`: `server.port: 5174`

## 📝 License

This project is created for educational purposes.

## 👨‍💻 Author

Built with ❤️ for the Food Delivery System

---

**Happy Coding! 🚀**
