# Prerequisites Installation Guide for Windows

## Current Status
❌ Java - Not installed
❌ Maven - Not installed  
❌ Node.js - Not installed
❌ MySQL - Not installed

## Installation Steps

### 1. Install Java 17 (Required for Backend)

**Option A: Using Chocolatey (Recommended)**
```powershell
# Install Chocolatey first if not installed
Set-ExecutionPolicy Bypass -Scope Process -Force; [System.Net.ServicePointManager]::SecurityProtocol = [System.Net.ServicePointManager]::SecurityProtocol -bor 3072; iex ((New-Object System.Net.WebClient).DownloadString('https://community.chocolatey.org/install.ps1'))

# Install Java
choco install openjdk17 -y
```

**Option B: Manual Installation**
1. Download from: https://adoptium.net/temurin/releases/?version=17
2. Choose Windows x64 installer (.msi)
3. Run installer and follow prompts
4. Verify: `java -version`

### 2. Install Maven (Required for Backend)

**Option A: Using Chocolatey**
```powershell
choco install maven -y
```

**Option B: Manual Installation**
1. Download from: https://maven.apache.org/download.cgi
2. Extract to `C:\Program Files\Apache\maven`
3. Add to PATH: `C:\Program Files\Apache\maven\bin`
4. Verify: `mvn -version`

### 3. Install Node.js (Required for Frontend)

**Option A: Using Chocolatey**
```powershell
choco install nodejs-lts -y
```

**Option B: Manual Installation**
1. Download from: https://nodejs.org/en/download/
2. Choose Windows Installer (.msi) - LTS version
3. Run installer (includes npm)
4. Verify: `node -v` and `npm -v`

### 4. Install MySQL (Required for Database)

**Option A: Using Chocolatey**
```powershell
choco install mysql -y
```

**Option B: Manual Installation**
1. Download from: https://dev.mysql.com/downloads/installer/
2. Choose MySQL Installer for Windows
3. Select "Developer Default" setup type
4. Set root password during installation (remember this!)
5. Verify: `mysql --version`

**Option C: Use XAMPP (Easiest for beginners)**
1. Download from: https://www.apachefriends.org/download.html
2. Install XAMPP
3. Start MySQL from XAMPP Control Panel
4. Default credentials: username=root, password=(empty)

### 5. Alternative: Use Docker (All-in-One Solution)

If you have Docker Desktop installed, you can run MySQL in a container:

```powershell
# Run MySQL in Docker
docker run --name food-delivery-mysql -e MYSQL_ROOT_PASSWORD=root -e MYSQL_DATABASE=food_delivery_auth -p 3306:3306 -d mysql:8.0

# Verify it's running
docker ps
```

## Quick Installation (Recommended)

**For Windows users, the fastest way is using Chocolatey:**

1. Open PowerShell as Administrator
2. Run these commands:

```powershell
# Install Chocolatey
Set-ExecutionPolicy Bypass -Scope Process -Force; [System.Net.ServicePointManager]::SecurityProtocol = [System.Net.ServicePointManager]::SecurityProtocol -bor 3072; iex ((New-Object System.Net.WebClient).DownloadString('https://community.chocolatey.org/install.ps1'))

# Install all prerequisites
choco install openjdk17 maven nodejs-lts mysql -y

# Restart PowerShell after installation
```

3. Close and reopen PowerShell/Terminal
4. Verify installations:
```powershell
java -version
mvn -version
node -v
npm -v
mysql --version
```

## After Installation

Once all prerequisites are installed:

### 1. Setup Database
```powershell
# Start MySQL service (if not running)
net start MySQL80

# Create database
mysql -u root -p
# Enter your MySQL password, then run:
# CREATE DATABASE food_delivery_auth;
# exit;

# Or use the SQL file
mysql -u root -p < database/schema.sql
```

### 2. Run Backend
```powershell
cd backend
mvn clean install
mvn spring-boot:run
```
Backend will run on: http://localhost:8080

### 3. Run Frontend
```powershell
cd frontend
npm install
npm run dev
```
Frontend will run on: http://localhost:5173

## Troubleshooting

### Java/Maven not found after installation
- Close and reopen your terminal
- Check if added to PATH: `echo $env:PATH`
- Restart your computer

### MySQL connection issues
- Ensure MySQL service is running: `net start MySQL80`
- Check credentials in `backend/src/main/resources/application.properties`
- Default username: `root`, password: (what you set during installation)

### Node/npm not found
- Restart terminal after installation
- Verify installation path is in PATH

## Need Help?

If you encounter any issues during installation, let me know which step is causing problems!
